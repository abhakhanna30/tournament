import { Component, OnInit } from '@angular/core';
import { Country } from 'src/app/models/country.model';
import { CountryService } from './country.service';

@Component({
  selector: 'app-country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.css']
})
export class CountryListComponent implements OnInit {

  country = {
    id: 0,
    name: '',
    ranking: 0,
  }
  edit = true;
  add = false;
  countries: Country[] | undefined;

  constructor(private countryService: CountryService) { }

  ngOnInit(): void {
    this.getCountries()
  }

  private getCountries() {
    this.countryService.getCountries().subscribe(country => this.countries = country);
  }

  addCountry() {
    const data = {
      name: this.country.name,
      id: this.country.id,
      ranking: this.country.ranking,
    };
    this.countryService.createCountry(data).subscribe(response => {
      console.log(response)
      this.getCountries();
    });
  }

  removeCountry(country: Country) {
    const id = country.id;
    console.log(country)
    this.countryService.deleteCountry(id).subscribe(country => console.log(country));
    this.getCountries();
  }

  updateCountry() {
    this.countryService.editCountry(this.country).subscribe(response => console.log(response));
    this.getCountries();
  }
}