import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Country } from 'src/app/models/country.model';
@Injectable({
  providedIn: 'root'
})
export class CountryService {
  private CountriesUrl = 'api/countries/';
  constructor(private http: HttpClient) { }

  getCountries(): Observable<Country[]> {
    return this.http.get<Country[]>(this.CountriesUrl).pipe(
      retry(2),
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        return throwError(error);
      })
    );
  }

  createCountry(Country: Country): Observable<Country> {
    return this.http.post<Country>(this.CountriesUrl, Country).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        return throwError(error);
      })
    )
  }

  editCountry(Country: Country): Observable<any> {
    return this.http.put(this.CountriesUrl + Country.id, Country);
  }

  deleteCountry(id: number): Observable<any> {
    return this.http.delete(this.CountriesUrl + id);
  }
}