export interface Player {
    FirstName: string;
    LastName: string;
    DOB: string;
    gender: Gender;
}

export enum Gender {
    Female = 1,
    Male = 2
}
